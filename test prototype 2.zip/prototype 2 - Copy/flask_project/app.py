from flask import Flask, request, jsonify, render_template
from azure.cognitiveservices.vision.customvision.prediction import CustomVisionPredictionClient
from msrest.authentication import ApiKeyCredentials
import os
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, static_folder='static')
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# SQLite database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///animal_behavior_db.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Azure Custom Vision settings
PREDICTION_KEY = "2THQqGizFxlQbwZcRe5MUAxor5Mamk9T0YaaR6CrmYNrKRYmPPOyJQQJ99BBACYeBjFXJ3w3AAAIACOGgb3N"
ENDPOINT = "https://elancogeneraltraining-prediction.cognitiveservices.azure.com/"
PROJECT_ID = "1b0da672-a88c-4012-a141-89b899276dee"
ITERATION_NAME = "Iteration4"

# Initialize prediction client
prediction_credentials = ApiKeyCredentials(in_headers={"Prediction-key": PREDICTION_KEY})
predictor = CustomVisionPredictionClient(ENDPOINT, prediction_credentials)

# Define the database models
class Prediction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255))
    behavior = db.Column(db.String(255))
    probability = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

class Behavior(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    behavior_name = db.Column(db.String(255), unique=True, nullable=False)
    description = db.Column(db.Text)
    solutions = db.Column(db.Text)  # Possible solutions to take

# Create database tables within an application context
with app.app_context():
    db.create_all()

    # behaviors
    behaviors = [
        {'behavior_name': 'sleeping', 'description': 'The animal is sleeping.', 'solutions': 'No action needed.'},
        {'behavior_name': 'running', 'description': 'The animal is running.', 'solutions': 'Ensure the environment is safe.'},
        {'behavior_name': 'itching', 'description': 'The animal is itching.', 'solutions': 'Check for fleas or ticks. Consult a veterinarian if needed.'},
        {'behavior_name': 'aggression', 'description': 'The animal is showing aggressive behavior.', 'solutions': 'Separate the animal from others. Monitor its behavior and consult a veterinarian if necessary.'},
        {'behavior_name': 'foot and mouth disease', 'description': 'The animal might have foot and mouth disease.', 'solutions': 'Isolate the animal. Contact a veterinarian immediately for further action.'}
        # Add more behaviors as needed
    ]
    for behavior_data in behaviors:
        # Check if the behavior already exists
        existing_behavior = Behavior.query.filter_by(behavior_name=behavior_data['behavior_name']).first()
        if not existing_behavior:
            behavior = Behavior(**behavior_data)
            db.session.add(behavior)
    db.session.commit()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        try:
            # Save the uploaded file
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filepath)

            # Analyze the image using the trained model
            with open(filepath, 'rb') as image_contents:
                results = predictor.classify_image(
                    PROJECT_ID,
                    ITERATION_NAME,
                    image_contents.read()
                )

            # Process predictions
            predictions = []
            for prediction in results.predictions:
                predictions.append({
                    'behavior': prediction.tag_name,
                    'probability': f"{prediction.probability * 100:.2f}%"
                })

            # Sort predictions by probability
            predictions.sort(key=lambda x: float(x['probability'][:-1]), reverse=True)

            return jsonify({
                'predictions': predictions,
                'top_behavior': predictions[0]['behavior'],
                'confidence': predictions[0]['probability']
            })

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)