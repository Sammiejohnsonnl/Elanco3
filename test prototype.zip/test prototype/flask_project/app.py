from flask import Flask, request, jsonify, render_template
from azure.cognitiveservices.vision.customvision.prediction import CustomVisionPredictionClient
from msrest.authentication import ApiKeyCredentials
import os

app = Flask(__name__, static_folder='static')
app.config['UPLOAD_FOLDER'] = 'uploads'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Azure Custom Vision settings
PREDICTION_KEY = "2THQqGizFxlQbwZcRe5MUAxor5Mamk9T0YaaR6CrmYNrKRYmPPOyJQQJ99BBACYeBjFXJ3w3AAAIACOGgb3N"
ENDPOINT = "https://elancogeneraltraining-prediction.cognitiveservices.azure.com/"
PROJECT_ID = "1b0da672-a88c-4012-a141-89b899276dee"
MODEL_NAME = "behaviorModel"

# Initialize prediction client
prediction_credentials = ApiKeyCredentials(in_headers={"Prediction-key": PREDICTION_KEY})
predictor = CustomVisionPredictionClient(ENDPOINT, prediction_credentials)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        try:
            # Save the uploaded file
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filepath)

            # Analyze the image using the trained model
            with open(filepath, 'rb') as image_contents:
                results = predictor.classify_image(
                    PROJECT_ID,
                    MODEL_NAME,
                    image_contents.read()
                )

            # Process predictions
            predictions = []
            for prediction in results.predictions:
                predictions.append({
                    'behavior': prediction.tag_name,
                    'probability': f"{prediction.probability * 100:.2f}%"
                })

            # Sort predictions by probability
            predictions.sort(key=lambda x: float(x['probability'][:-1]), reverse=True)

            return jsonify({
                'predictions': predictions,
                'top_behavior': predictions[0]['behavior'],
                'confidence': predictions[0]['probability']
            })

        except Exception as e:
            return jsonify({'error': str(e)}), 500

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)